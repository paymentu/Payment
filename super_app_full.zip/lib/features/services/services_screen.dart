
import 'package:flutter/material.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = ["Recharge","Bills","Shopping","Food"];

    return Scaffold(
      appBar: AppBar(title: const Text("Services")),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2),
        itemBuilder: (_, i) {
          return Card(
            child: Center(child: Text(items[i])),
          );
        },
      ),
    );
  }
}
