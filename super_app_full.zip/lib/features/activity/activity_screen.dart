
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/transaction_provider.dart';

class ActivityScreen extends StatefulWidget {
  const ActivityScreen({super.key});

  @override
  State<ActivityScreen> createState() => _ActivityScreenState();
}

class _ActivityScreenState extends State<ActivityScreen> {

  @override
  void initState() {
    super.initState();
    Provider.of<TransactionProvider>(context, listen: false).listen();
  }

  @override
  Widget build(BuildContext context) {
    final tx = Provider.of<TransactionProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text("Activity")),
      body: ListView(
        children: tx.transactions.map((e) {
          return ListTile(
            title: Text("Amount: ${e['amount']} ${e['currency']}"),
          );
        }).toList(),
      ),
    );
  }
}
