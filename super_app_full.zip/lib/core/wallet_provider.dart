
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class WalletProvider extends ChangeNotifier {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  Future sendMoney(String receiverId, double amount, String currency) async {
    final user = _auth.currentUser!;
    final senderRef = _db.collection("users").doc(user.uid);
    final receiverRef = _db.collection("users").doc(receiverId);

    await _db.runTransaction((tx) async {
      final sender = await tx.get(senderRef);
      final receiver = await tx.get(receiverRef);

      double senderBal = sender["balances"][currency];
      double receiverBal = receiver["balances"][currency];

      if (senderBal < amount) throw Exception("Insufficient funds");

      tx.update(senderRef, {"balances.$currency": senderBal - amount});
      tx.update(receiverRef, {"balances.$currency": receiverBal + amount});
    });

    await _db.collection("transactions").add({
      "senderId": user.uid,
      "receiverId": receiverId,
      "amount": amount,
      "currency": currency,
      "timestamp": DateTime.now(),
    });
  }
}
