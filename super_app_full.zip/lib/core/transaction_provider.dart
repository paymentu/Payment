
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class TransactionProvider extends ChangeNotifier {
  final _db = FirebaseFirestore.instance;
  List transactions = [];

  void listen() {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    _db.collection("transactions")
      .where("senderId", isEqualTo: uid)
      .snapshots()
      .listen((snap) {
        transactions = snap.docs;
        notifyListeners();
      });
  }
}
